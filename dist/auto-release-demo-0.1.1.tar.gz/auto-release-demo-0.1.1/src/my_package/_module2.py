def function3(variable3):
    """
    Lorem ipsum yadiyaasdfyjfgyhj


    Parameters
    ----------
    t1: int
        Some text

    Returns
    -------
    int
        A number

    """

    return 4


def function4(variable4):
    """
    Lorem ipsum yadiyasdfgnb


    Parameters
    ----------
    t1: int
        Some text

    Returns
    -------
    int
        A number

    """

    return 4
