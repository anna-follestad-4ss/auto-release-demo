class Class1:
    """
    Lorem ipsum yadiyasdfgnb


    Parameters
    ----------
    t1: int
        Some text

    Returns
    -------
    int
        A number

    """

    def functioninclass1(self, t2):
        """
        a docstring here also

        Parameters
        ----------
        t2: int
            Some text

        Returns
        -------
        int
            a number
        """
        return 1

    def functioninclass2(self, t2):
        """
        a docstring here also for the second one

        Parameters
        ----------
        t2: int
            Some text

        Returns
        -------
        int
            a number
        """
        return 1
