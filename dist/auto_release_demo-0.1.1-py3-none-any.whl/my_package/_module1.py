def _privatefunction(variable2):
    """
    This is a private function

    Parameters
    ----------

    variable2: int
        it should not appear

    Returns
    -------
    int
        Nothing

    """
    return 0


def function1(variable1):
    """
    Lorem ipsum yadiyaasdf


    Parameters
    ----------
    t1: int
        Some text

    Returns
    -------
    int
        A number

    """

    return 4


def function2(variable2):
    """
    Lorem ipsum yadiyadfg
    vdfg

    Parameters
    ----------
    t1: int
        Some text

    Returns
    -------
    int
        A number

    """

    return 4
